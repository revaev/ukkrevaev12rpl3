<?php
$server= "localhost";
$username = "root";
$password = "";
$db = "pembayaran spp";

$koneksi = new mysqli
("$server", "$username", "$password", "$db");

if(!$koneksi){
    die(mysql_error($koneksi));
}

?>