<?php
include 'koneksi.php';
if(isset($_POST["ok"])) {
    $nis = $_POST["nis"];
    $nama = $_POST["nama"];
    $id_kelas = $_POST["id_kelas"];
    $input = mysqli_query($koneksi, "UPDATE siswa SET nis='$nis', nama='$nama', id_kelas='$id_kelas', nis='$nis' WHERE nama_='$nama_'");
    echo "<div class='alert alert-success'>UPDATE SUKSES!</div>";
        header("location:tabelsiswa.php");
}
?>
<!doctype html>
    <html lang="en">
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integri>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <style>
            * {
                font-family: 'Roboto', sans-serif;
            }

            body {
                background: #708090;
                background-size: cover;
                background-repeat: no-repeat;
                background-position: center;
                background-attachment: fixed;
            }
        </style>
        <title>PEMBAYARAN SPP</title>
    </head>
    <body class="text-white">
        
        <h1 class="text-center mt-5">PEMBAYARAN SPP</h1>
        <h3 class="text-center mt-5" style="color:#8acaff">FORM UPDATE SISWA</h3>
    <div class="container">
        <?php
        include 'koneksi.php';
        $id_kelas = $_GET['id_kelas'];
        $update = mysqli_query($koneksi, "SELECT * FROM siswa WHERE id_kelas='$id_kelas'");
        foreach ($update as $row) {

        
        ?>
          <form action="" method="post">
    <div class="row justify-content-center">
        <div class="col-5">
        <form class="mt-4">
    <div class="form-group">
        <label>Nis</label>
        <input class="form-control" type="text" id="nis" name="nis" value="<?php echo $row['nis']; ?>" >
    </div>
    <div class="form-group">
        <label>Nama</label>
        <input class="form-control" type="text" id="nama" name="nama" value="<?php echo $row['nama']; ?>" >
    </div>
    <div class="form-group">
        <label> Id Kelas </label>
          <input class="form-control" type="text" id="id_kelas" name="id_kelas" value="<?php echo $row['id_kelas']; ?>" >
    </div> 
    <div class="form-group">
       
    </div>
    <center><button type="submit" name="ok"class="btn btn-dark">Submit</button></center>
</form>
</div>
<?php }?>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN"></script>

</body>
</html>