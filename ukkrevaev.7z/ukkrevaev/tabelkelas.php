<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https:fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
	<style>
		* {
			font-family: 'Roboto', sans-serif;
		}
		body{
			background: #708090;
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center;
			background-attachment: fixed;
		}
	</style>
	<title>PEMBAYARAN SPP</title>
</head>
<br>
<body class="text-white">
	<h1 class="text-center mt-5" style="color: white;">Tabel Kelas</h1>

	<div class="container">
		<div class="row justify-content-center">
			<div class="col-10">
			<form action="" align="center" method="post">
      Cari Bedasarkan :  <select name="pilih">
      
             <option value="id_kelas"> Id Kelas</option>
              <option value="nama_kelas"> Nama_Kelas</option>
              </select>
              <input type="text" name="textcari" size="24" />
              <input type="submit" name="cari" value="cari" />
              <input type="submit" name="semua" value="tampilkan semua" />
        </form>
        
			<table class="table table-bordered bg-light mt-5">
				<thead class="thead-dark text-center">
					<tr>
						<th scope="col">No</th>
						<th scope="col">Id Kelas</th>
						<th scope="col">Nama Kelas</th>
						<th scope="col">Kompetensi Keahlian</th>
						<th scope="col">aksi</th>
					</tr>
				</thead>
			</tbody>
		
			<?php
    include 'koneksi.php';
    $input="";
    if (isset($_POST['cari'])) {
    	$opsi=$_POST['pilih'];
        $nama=$_POST["textcari"];
        $input = mysqli_query($koneksi,  "SELECT * from kelas WHERE $opsi LIKE '%$nama%'" );
   
    }else{
$input=mysqli_query($koneksi, "SELECT * from kelas");
    }
    $no = 1;
    foreach ($input as $row){
        echo "<tr>
        <td>$no</td>

        <td>" . $row['id_kelas'] . "</td>
		<td>" . $row['nama_kelas'] . "</td>
		<td>" . $row['kompetensi_keahlian'] . "</td>
       
		<td>
					<a href='update.php?id_kelas=$row[id_kelas]'>
					<input type='button'  class='btn btn-success'
				value='edit'></a>

					<a href='hapus.php?id_kelas=$row[id_kelas]'>
					<input type='button'  class='btn btn-danger'
					value='hapus'></a>
					</td></tr>";
        $no++;
    }
    ?>  
			</tbody>
			</div>
		</div>
	</div>
	
	<script scr="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-"></script>

</body>
</html>