<!doctype html>
	<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integri>
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
		<style>
			* {
				font-family: 'Roboto', sans-serif;
			}

			body {

				background-color: #708090;
				background-size: cover;
				background-repeat: no-repeat;
				background-position: center;
				background-attachment: fixed;
			}

		</style>
		<title>PEMBAYARAN SPP</title>
	</head>

	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar ftco-navbar-light site-navbar-target" id="ftco-navbar">
	    <div class="container">
	      
	      <button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav nav ml-auto">
	          <li class="nav-item"><a href="index.html" class="nav-link"><span>Home</span></a></li>
	          <li class="nav-item"><a href="tabelsiswa.php" class="nav-link"><span>Siswa</span></a></li>
			  <li class="nav-item"><a href="kelas.php" class="nav-link"><span>Kelas</span></a></li>
			  <li class="nav-item"><a href="bayar.php" class="nav-link"><span>Pembayaran</span></a></li>
	          <li class="nav-item"><a href="login.php" class="nav-link"><span>Logout</span></a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
	<body class="text-black">
		
		<h3 class="text-center mt-4" style="color:white">FORM KELAS</h3>
	<div class="container">
		<?php
            include 'koneksi.php';
            if (isset($_POST["ok"])){
                $id_kelas = $_POST["id_kelas"];
                $nama_kelas = $_POST["nama_kelas"];
                $kompetensi_keahlian = $_POST["kompetensi_keahlian"];
                $input = mysqli_query($koneksi, "insert into kelas (id_kelas,nama_kelas,kompetensi_keahlian) values ('$id_kelas','$nama_kelas','$kompetensi_keahlian')");
                echo "<div class= 'alert alert-success'> Sukses! </div>";
            }
            ?>
	<div class="row justify-content-center">
		<div class="col-5">
		<form class="mt-4" method="post" action="kelas.php">
	<div class="form-group">
	    <label> Id kelas</label>
	    <input type="text" id="id_kelas" name="id_kelas" class="form-control">
	</div>
	<div class="form-group">
		<label> Nama Kelas</label>
		<input type="text" id="nama_kelas" name="nama_kelas" class="form-control">
	</div>
	<div class="form-group">
		<label> Kompetensi Keahlian</label>
		<input type="text" id="kompetensi_keahlian" name="kompetensi_keahlian" class="form-control">
	</div>
	<div class="form-group">
		
	<div class="form-group">
		
	</div>
	<center>
		<button type="reset" class="btn btn-dark">Cancel</button>
	<button type="submit" class="btn btn-dark" name="ok">Submit</button>
	<a style="color: white;" href="tabelkelas.php" class="btn btn-dark">Lihat tabel kelas</a>
</center>
</form>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN"></script>

</body>
</html>