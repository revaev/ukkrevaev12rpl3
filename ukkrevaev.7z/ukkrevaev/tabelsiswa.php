<!doctype html>
	<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integri>
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
		<style>
			* {
				font-family: 'Roboto', sans-serif;
			}

			body {
				background: #708090;
				background-size: cover;
				background-repeat: no-repeat;
				background-position: center;
				background-attachment: fixed;
			}
		</style>
		<title>PEMBAYARAN SPP</title>
	</head>
	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar ftco-navbar-light site-navbar-target" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="#"></a>
	      <button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav nav ml-auto">
	          <li class="nav-item"><a href="index.html" class="nav-link"><span>Home</span></a></li>
	          <li class="nav-item"><a href="tabelsiswa.php" class="nav-link"><span>Siswa</span></a></li>
			  <li class="nav-item"><a href="kelas.php" class="nav-link"><span>Kelas</span></a></li>
			  <li class="nav-item"><a href="bayar.php" class="nav-link"><span>Pembayaran</span></a></li>
	          <li class="nav-item"><a href="login.php" class="nav-link"><span>Logout</span></a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
	<body class="text-white">
		<h1 class="text-center mt-5">Tabel Siswa</h1>
	<div class="container">
    
	<div class="row justify-content-center">
	<div class="col-9"> <br>
	    <table class="table bg-light">
	<thead class="thead-dark">
		<tr>
		<th scope="col">No.</th>
		<th scope="col">NIS</th>
        <th scope="col">Nama</th>
        <th scope="col">Id Kelas</th>
         <th scope="col">Aksi</th>
    </tr>
    </thead>
    <form action="" align="center" method="post">
      Cari Bedasarkan :  <select name="pilih">
      
             
              <option value="NIS"> NIS</option>
               <option value="nama"> Nama</option>
              </select>
              <input type="text" name="textcari" size="24" />
              <input type="submit" name="cari" value="cari" />
              <input type="submit" name="semua" value="tampilkan semua" />
        </form>

    <body>
   <?php
    include 'koneksi.php';
    $input = mysqli_query($koneksi, "SELECT * from siswa");
    if (isset($_POST['cari'])) {
        $nama=$_POST["textcari"];
        $input = mysqli_query($koneksi,  "SELECT * from siswa WHERE NIS LIKE '%$nama%' OR nama LIKE '%$nama%' OR id_kelas LIKE '%$nama%'" );
   
    }else{
$input=mysqli_query($koneksi, "SELECT * from siswa");
    }

    $no = 1;
    foreach ($input as $row){
        echo "<tr>
        <td>$no</td>
        <td>" . $row['nis'] . "</td>
        <td>" . $row['nama'] . "</td>
        <td>" . $row['id_kelas'] . "</td>
        <td>
					<a href='update.php?nis=$row[nis]'>
					<input type='button'  class='btn btn-success'
				value='edit'></a>

					<a href='hapus.php?nis=$row[nis]'>
					<input type='button'  class='btn btn-danger'
					value='hapus'></a>
					</td></tr>";
       
        $no++;
    }
    ?>
    </body>
</table>
</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN"></script>
</body>
</html>